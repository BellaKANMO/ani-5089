#include <cstdio>

#include "actions.h"

namespace {

    constexpr int kImages = 6;
    constexpr int kActions = 3;

    const char *kNoms[kActions] = {"tirer", "saisir", "morte"};

    const bool kTouches[kActions][kImages] = {
        {false, true, true, true, false, false},
        {false, false, false, false, true, false},
        {false, true, true, true, false, false},
    };

    const EtatAction kAttendu[kActions][kImages] = {
        {{false, false, true}, {true, true, true}, {true, false, true},
         {true, false, true}, {false, true, true}, {false, false, true}},
        {{false, false, true}, {false, false, true}, {false, false, true},
         {false, false, true}, {true, true, true}, {false, true, true}},
        {{false, false, false}, {false, false, false}, {false, false, false},
         {false, false, false}, {false, false, false}, {false, false, false}},
    };

    bool Egaux(const EtatAction &a, const EtatAction &b) {
        return a.current == b.current && a.changed == b.changed && a.active == b.active;
    }

    int Largeur(const char *nom, int champ) {
        int longueur = 0;
        while (nom[longueur] != '\0') {
            ++longueur;
        }
        return longueur + 1 + champ;
    }

    EtatAction CalculFautif(bool lie, bool presse, bool &precedentTouche) {
        EtatAction etat;
        etat.active = lie;
        etat.current = lie ? presse : false;
        etat.changed = presse != precedentTouche;
        precedentTouche = presse;
        return etat;
    }

}

int main() {
    Action actions[kActions] = {Action(true), Action(true), Action(false)};
    const bool lies[kActions] = {true, true, false};

    std::printf("image");
    for (int a = 0; a < kActions; ++a) {
        std::printf(" %s_current %s_changed %s_active", kNoms[a], kNoms[a], kNoms[a]);
    }
    std::printf("\n");

    int ecarts = 0;
    for (int image = 0; image < kImages; ++image) {
        std::printf("%5d", image + 1);
        for (int a = 0; a < kActions; ++a) {
            const EtatAction etat = actions[a].MettreAJour(kTouches[a][image]);
            std::printf(" %*d %*d %*d", Largeur(kNoms[a], 7), etat.current ? 1 : 0,
                        Largeur(kNoms[a], 7), etat.changed ? 1 : 0, Largeur(kNoms[a], 6),
                        etat.active ? 1 : 0);
            if (!Egaux(etat, kAttendu[a][image])) {
                ++ecarts;
            }
        }
        std::printf("\n");
    }

    int ecartsFautifs = 0;
    bool precedentTouche[kActions] = {false, false, false};
    for (int image = 0; image < kImages; ++image) {
        for (int a = 0; a < kActions; ++a) {
            const EtatAction etat = CalculFautif(lies[a], kTouches[a][image], precedentTouche[a]);
            if (!Egaux(etat, kAttendu[a][image])) {
                ++ecartsFautifs;
            }
        }
    }

    std::printf("verification : %s (%d ecart)\n", ecarts == 0 ? "OK" : "ECHEC", ecarts);
    std::printf("version fautive, changed calcule sur la touche : %d ecarts detectes\n", ecartsFautifs);

    return ecarts == 0 && ecartsFautifs > 0 ? 0 : 1;
}
