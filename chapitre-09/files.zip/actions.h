#ifndef ACTIONS_H
#define ACTIONS_H

struct EtatAction {
    bool current = false;
    bool changed = false;
    bool active = false;
};

class Action {
public:
    explicit Action(bool lie) : lie_(lie) {}

    EtatAction MettreAJour(bool presse) {
        EtatAction etat;
        etat.active = lie_;
        etat.current = etat.active ? presse : false;
        etat.changed = etat.current != precedent_;
        precedent_ = etat.current;
        return etat;
    }

private:
    bool lie_;
    bool precedent_ = false;
};

#endif
